//  Set the height of the header to the height of the video player 
function setIntroVideoSize() {
	var videoHeight = $('#intro-video').height();
	$('header').css('height', videoHeight + 'px');
	$('article').css('display', 'block');
}

//  Adjust the header when the browser width is changed
function adjustHeaderOnResize() {
	$(window).resize(function() {
		setIntroVideoSize();
	});
} 

function tabEventHandler() {
	$('nav li').click(function(evt) {
		evt.stopImmediatePropagation();

		$('nav ul').find('.active').removeClass('active');
		$(this).addClass('active');

		displayTabContent();
	});
}

function displayTabContent() {
	var active_tab = $('#tabs').find('.active a').attr('class');
	$('article .contents section').hide();
	$('article .contents').find('.' + active_tab + '').css('display', 'block');
}

function handleArrowClick() {
	$('.down-arrow').click(function(evt) {
		evt.stopImmediatePropagation;

		$('html, body').animate({
    		scrollTop: $(".main_action").offset().top
		}, 800);
	});	
}

$(function initilize() {
	window.setTimeout(function() {setIntroVideoSize();}, 200); 
	adjustHeaderOnResize();
	tabEventHandler();
	displayTabContent();
	handleArrowClick();
});