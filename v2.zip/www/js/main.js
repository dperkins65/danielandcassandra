//  Set the height of the header to the height of the video player 
function setIntroVideoSize() {
	var videoHeight = $('#intro-video').height();
    var tabsHeight = 120;
    var windowHeight = window.innerHeight;
	
    $('.header').css('max-height', (windowHeight - tabsHeight) + 'px'); 
    $('.header').css('height', videoHeight + 'px');
    $('.overlay').css('height', videoHeight + 'px');
    $('article').css('min-height', windowHeight + 'px'); 
}

//  Adjust the header when the browser width is changed
function adjustHeaderOnResize() {
    "use strict";
    
	$(window).resize(function () {
		setIntroVideoSize();
	});
}

function displayTabContent() {
    "use strict";
    
	var active_tab = $('#tabs').find('.active a').attr('class');
	$('article .contents section').hide();
	$('article .contents').find('.' + active_tab + '').css('display', 'block');
}

function tabEventHandler() {
    "use strict";
	$('nav li').click(function (evt) {
        
        "use strict";
		evt.stopImmediatePropagation();

		$('nav ul').find('.active').removeClass('active');
		$(this).addClass('active');

		displayTabContent();
	});
}

function linkEventHandler() {
    $('.splash-letter span').click(function (evt) {
        evt.stopImmediatePropagation();
        
        var targetTab = '.' + $(this).attr('target-tab');
        $('nav ul').find('.active').removeClass('active');
        $('nav ul').find(targetTab).parent().addClass('active');
        
        displayTabContent();
    });
}

$(function initilize() {
    "use strict";
	window.setTimeout(function() {setIntroVideoSize();}, 100); 
	adjustHeaderOnResize();
	tabEventHandler();
	displayTabContent();
    linkEventHandler();
});